## Hi all!

Welcome to the `histogramr` package.

For examples on how to use the function refer the readme.rmd file in this repository. Alternatively, you can visit https://github.com/stat545ubc-2023/assignment-b1-Jasleen-Kaur-M to understand how the function works in detail.


### Install
Make sure that devtools is installed by running install.packages("devtools"), then type

devtools::install_github("stat545ubc-2023/histogramr")

Happy coding✌🏻

Cheers😉
